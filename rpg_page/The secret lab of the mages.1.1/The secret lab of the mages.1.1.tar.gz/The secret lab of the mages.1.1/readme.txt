The secret lab of the mages / Das geheime Labor der Magier
==========================================================

A One Page Dungeon for fantasy settings in German and English.

Download: http://www.heldenschmiede.ch

Files:

Das geheime Labor der Magier.1.1.svg

Source SVG graphic produced whit Inkscape. There are two layers
"Text EN" and "Text DE". Switch the visibility to see the
other language.
If you want the map for your players, you can switch of layers
like "Traps" and "Text *".
You will need the font Purisa whit german Umlauts installed to
see the text correctly. You can find it in some thai-tlwg
packages like the one from:
http://www.rpmseek.com/rpm/t1-thai-tlwg_0.4.11-2_all.html?hl=de&cbn=0:T:0:6428227:0:0:0&ShowChangeLog=1


Das geheime Labor der Magier.1.1.pdf

The german version as PDF


The secret lab of the mages.1.1.pdf

The english version as PDF


License:

This work is licensed under the Creative Commons
Attribution-Share Alike 3.0 Unported License. To view a copy
of this license, visit
http://creativecommons.org/licenses/by-sa/3.0/
or send a letter to
Creative Commons
171 Second Street
Suite 300
San Francisco
California
94105
USA.
